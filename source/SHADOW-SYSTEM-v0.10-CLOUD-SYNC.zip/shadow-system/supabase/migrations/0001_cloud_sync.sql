-- SHADOW SYSTEM cloud sync foundation (Supabase / PostgreSQL)
-- Apply this migration in a dedicated Supabase project.
-- The application is NOT cloud-synced until the matching client/server integration is implemented.

create table if not exists public.hunter_cloud_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  revision bigint not null default 1 check (revision > 0),
  updated_at timestamptz not null default now()
);

alter table public.hunter_cloud_state enable row level security;

-- Users can read only their own cloud save.
create policy "hunter reads own cloud state"
  on public.hunter_cloud_state for select
  to authenticated
  using (auth.uid() = user_id);

-- Users can create only a row owned by their authenticated identity.
create policy "hunter creates own cloud state"
  on public.hunter_cloud_state for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Users can update only their own cloud save.
create policy "hunter updates own cloud state"
  on public.hunter_cloud_state for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- No anonymous access. No client-side delete policy by design.
revoke all on public.hunter_cloud_state from anon;
grant select, insert, update on public.hunter_cloud_state to authenticated;

create index if not exists hunter_cloud_state_updated_at_idx
  on public.hunter_cloud_state (updated_at desc);
