@echo off
cd /d "%~dp0"
title INSTALL SHADOW SYSTEM
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js is missing. Install Node.js 22.5 or newer from https://nodejs.org/
 echo Then run INSTALL-SHADOW-SYSTEM.bat again.
 pause
 exit /b 1
)
for /f %%a in ('node -p "process.versions.node.split('.')[0]"') do set NODEMAJOR=%%a
if %NODEMAJOR% LSS 22 (
 echo Node.js 22.5 or newer is required. Current version:
 node -v
 pause
 exit /b 1
)
if not exist data mkdir data
powershell -NoProfile -ExecutionPolicy Bypass -Command "$W=New-Object -ComObject WScript.Shell; $S=$W.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\SHADOW SYSTEM.lnk'); $S.TargetPath='%~dp0START-SHADOW-SYSTEM.bat'; $S.WorkingDirectory='%~dp0'; $S.IconLocation='%~dp0public\assets\icon.svg'; $S.Save()"
if errorlevel 1 (
 echo Could not create desktop shortcut. You can still run START-SHADOW-SYSTEM.bat.
) else (
 echo Desktop shortcut created.
)
echo Installation setup complete. Start SHADOW SYSTEM from the desktop shortcut.
pause
