@echo off
cd /d "%~dp0"
title SHADOW SYSTEM
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js 22.5 or newer is required.
 echo Install the LTS version from https://nodejs.org/ and run this file again.
 pause
 exit /b 1
)
for /f %%a in ('node -p "process.versions.node.split('.')[0]"') do set NODEMAJOR=%%a
if %NODEMAJOR% LSS 22 (
 echo Node.js 22.5 or newer is required. Current version:
 node -v
 pause
 exit /b 1
)
if not exist data mkdir data
echo Starting SHADOW SYSTEM...
echo Keep this window open while using the app.
echo On this PC: http://localhost:4173
 echo On your phone, use this PC's LAN IP and port 4173 while on the same Wi-Fi.
start "SHADOW SYSTEM" http://localhost:4173
node server.js
pause
