# SHADOW SYSTEM — Cloud Sync Setup

## v0.10 status
The app includes optional Supabase email/password cloud identity and manual snapshot upload/restore in Settings. Cloud sign-in is separate from the device's local Hunter login.

1. Apply `supabase/migrations/0001_cloud_sync.sql` to the Supabase project.
2. Enable Email authentication. If email confirmation is enabled, confirm the registration email before logging in.
3. Open SHADOW SYSTEM > Settings > Cloud Synchronization.
4. Register or log into a Supabase email account.
5. Use **Upload this device** to save the current local account snapshot, or **Restore from cloud** on another device.

## Important behavior
- Each Supabase Auth user can access only their own row through Row Level Security.
- Upload replaces that user's cloud snapshot.
- Restore replaces the current local account after a confirmation prompt. Export a local backup first.
- This is manual snapshot synchronization, not automatic bidirectional sync. Avoid simultaneous uploads from multiple devices; conflict-safe merge and automatic retry are future work.
- Supabase URL and publishable key are public client configuration. Never use or expose a service-role/secret key in the app, GitHub, or browser.
- Do not expose the local Node server directly to the public internet.
