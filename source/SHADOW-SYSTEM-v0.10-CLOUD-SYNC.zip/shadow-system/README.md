# SHADOW SYSTEM — Personal Calisthenics Training OS

A single-user, dark-themed calisthenics tracker delivered as a responsive Progressive Web App (PWA), served by a small Node.js API and a persistent SQLite database.

## Requirements
- Windows 10/11 or another OS with Node.js **22.5+** installed.
- A modern browser (Edge, Chrome, Firefox or Safari; PWA installation/notifications vary by platform).
- No npm packages are required. The backend uses Node's built-in HTTP server and `node:sqlite`.

## Start on Windows
1. Install Node.js 22.5 or newer from https://nodejs.org/ if it is not already installed.
2. Extract the complete ZIP into a normal writable folder (not inside a protected Program Files folder).
3. Double-click `START-SHADOW-SYSTEM.bat`.
4. Keep the terminal window open. The app opens at http://localhost:4173.
5. Use **Settings → Download full backup** regularly. The database lives in `data/shadow-system.sqlite`.

## Android and PC on the same Wi-Fi
1. Start the server on the Windows PC.
2. Find the PC's local IPv4 address (`ipconfig` in Command Prompt).
3. On Android, open `http://PC-IP:4173` in Chrome while connected to the same Wi-Fi.
4. Install/Add to Home screen from the browser menu.
5. The phone and PC access the same server database when using the same address. Allow Node.js through Windows Firewall on a private network if prompted.

**Important:** This is local-network access, not secure public cloud hosting. Do not expose port 4173 directly to the internet. Public multi-device access requires HTTPS, authentication, rate limiting, and a hardened deployment.

## Main features in this starter release
- Shadow-themed responsive dashboard and original SVG shadow emblem/monarch motif.
- SQLite persistence for profile, programmes, exercise library, workouts, and XP transactions.
- Weekly programme builder with day-by-day exercise assignment.
- Exercise library with technique steps, muscles, breathing, common mistakes, optional image upload/URL, video URL or uploaded MP4/WebM clips, custom categories, and custom exercise variations. Exercise cards and tutorials use real reference photos where an exact exercise match is verified; tutorials provide YouTube video search and image search for exercises without a matched local-library reference, plus embedded playback for supported YouTube links and uploaded clips.
- Workout session logger with set-by-set actual reps/hold seconds, completion toggles, rest timer, notes, and incomplete saves.
- XP awarded once per completed workout; duplicate completion does not duplicate the XP transaction.
- Calendar, workout history, streaks, achievements, and basic statistics.
- JSON backup/restore and CSV workout export.
- PWA installability and cached application shell.
- Settings → Interface Color Control lets you choose primary and secondary energy colors while retaining the fixed near-black / metallic SHADOW SYSTEM visual identity. Theme colors are saved in the database and included in JSON backups.
- Add Exercise lets you add exercises discovered later, create your own category, attach a demonstration image, add an external tutorial URL or upload a short MP4/WebM/OGG clip, and document easier/harder variations. New categories appear automatically in the library filter.
- Exercise tutorials use matched real photos from the public-domain Free Exercise DB for Standard Push-ups, Bodyweight Squats, Forearm Planks, Glute Bridges, and Dead Bugs. Exercises without an exact verified match do not receive an unrelated substitute image; instead, the tutorial offers direct searches for real videos and photos. YouTube watch links can play inside the tutorial; uploaded MP4/WebM/OGG clips play inline.

## Current limitations — read before relying on it
This is the first runnable foundation, not yet the full production specification:
- v0.9 adds password-protected local accounts with separate data on the same server. It is not cloud hosting or hardened public-internet authentication; use HTTPS and deployment hardening before any internet-facing use.
- Offline mode currently caches the application shell; workout writes require the server connection. Offline write queue and conflict-safe sync are not implemented yet.
- Browser reminders only run while the page/browser is active. Guaranteed background Android/Windows reminders need platform-specific push/background integration and permissions.
- The exercise starter records include written technique notes and built-in illustrative diagrams. Real-person video results are opened through YouTube search and require an internet connection; no third-party video is downloaded or bundled automatically. Uploaded video clips are stored inside the local database as encoded media; keep clips short (roughly 15–18 MB maximum source size) to stay within the API request limit and keep backups manageable. The animated figures are schematic illustrations rather than motion-captured exercise-specific biomechanics.
- No signed Windows `.exe` installer or native Android APK is included. Install as a PWA from Edge/Chrome. A packaged desktop/mobile build can be added after the backend/auth/sync model is finalized.
- The starter level curve is 500 XP per level; rank titles and cosmetic unlock progression are initial scaffolding.

## Data and backup
- SQLite file: `data/shadow-system.sqlite`.
- Use Settings → Download full backup to create a portable JSON backup.
- Restore replaces the current database's app records after confirmation. Keep a copy of the SQLite file as an additional backup while the server is stopped.

## Development
```bash
node --check server.js
node --check public/app.js
node server.js
```
Open http://localhost:4173. The server defaults to port 4173; set `PORT` to change it.


## v0.4 tutorial display fix
- Static app assets now use no-cache headers and versioned URLs.
- Service worker v4 activates immediately, claims open tabs, and refreshes app assets from the local server before using its offline cache.
- v0.4 refreshed static assets and service-worker activation to resolve stale cached files.
- If an older installed app still displays stale content, close all SHADOW SYSTEM tabs/windows and reopen it from START-SHADOW-SYSTEM.bat.

## v0.5 real exercise photo references
- Replaced generic stick-figure visuals with verified real-person photo references for five starter exercises.
- Uses the public-domain Free Exercise DB image pairs for start/movement positions. The source images are fetched from GitHub and cached by the service worker after first successful load.
- Unmatched exercises deliberately show that a verified photo is not yet attached, with direct YouTube video and Google Images searches rather than a misleading image of another movement.
- Photo credit/source: https://github.com/yuhonas/free-exercise-db (Unlicense).


## Exercise demonstration photo credits

The Exercise Library uses matched real exercise reference photos from the public-domain [Free Exercise DB](https://github.com/yuhonas/free-exercise-db) (Unlicense) for Standard Push-ups, Bodyweight Squats, Forearm Planks, Glute Bridges, and Dead Bugs. The app intentionally does not reuse an unrelated movement image for exercises without a verified match; those tutorials offer a direct YouTube search instead. External photos are cached by the service worker after first successful load, so they may remain available offline on that device.


## Version 0.6 — Exercise library layout repair

- Fixed malformed inline image error markup that could leak fragments such as `">` into the page.
- Image failures now switch to a clean fallback message using a safe event handler.
- Exercise cards now use a consistent image frame, aligned content, and a responsive 3/2/1-column layout for desktop, tablet, and mobile.
- Tutorial photos keep a contained aspect ratio instead of stretching across the card.
- Service worker cache version updated so browsers fetch the repaired interface.
- Existing SQLite data is preserved; the release ZIP intentionally excludes the `data` folder.

## Version 0.7 — Weekly training plans and exercise references

- Added five ready-made weekly plans: Full Body, Core, Upper Body, Lower Body, and Mobility & Recovery.
- Plans are added to **My Programmes** in a paused state. Activate or pause each plan independently; multiple active plans are combined into the dashboard's daily mission. Exercises appearing in more than one active plan are de-duplicated in the combined session.
- The dashboard shows the combined mission and selected training methods. Calendar schedule checks include all active programmes.
- Added training-method options to the weekly programme editor: straight sets, tempo reps, supersets, circuits, EMOM, AMRAP, timed holds, unilateral sets, mobility flow, and easy flow.
- Added a training-method reference covering progressive overload, tempo, supersets, circuits, EMOM, AMRAP, RIR/RPE, unilateral work, isometrics, and deloads.
- Added new exercise entries for bird dog, hollow body hold, side plank, reverse crunch, calf raise, glute bridge march, cat-cow, world's greatest stretch, thoracic rotation, ankle mobility, shoulder circles, and hip-flexor stretch. On existing installations these entries are appended only if their IDs are missing; existing exercise edits and workout history are not overwritten.
- Added matched external photo references for Diamond Push-up, Reverse Lunge, Pike Push-up, Reverse Snow Angel, and Burpee. Each tutorial includes a source credit/link. These are remotely hosted images, not bundled assets; first load requires internet and availability depends on the original publisher's host.
- The service worker cache version and asset URLs have been updated to avoid stale v0.6 files.

**Training note:** Activating several strength programmes can create a high combined workload, especially where the same muscle groups overlap. Start with one main strength plan; add mobility or light recovery work as appropriate. Scale reps and sets to your current ability, keep technique controlled, and retain recovery days.


## Version 0.8 — Complete mobility and core exercise picture set

- Added bundled local picture references for Bird Dog, Hollow Body Hold, Side Plank, Reverse Crunch, Standing Calf Raise, Glute Bridge March, Cat-Cow, World’s Greatest Stretch, Quadruped Thoracic Rotation, Knee-to-Wall Ankle Rock, Shoulder Circles, and Half-Kneeling Hip Flexor Stretch.
- These twelve images are original AI-generated illustrative references created for SHADOW SYSTEM, stored locally in `public/assets/exercises/` and included in the app-shell cache for offline viewing after the update.
- The images are visual references, not motion-captured demonstrations or medical guidance. Follow each exercise’s written steps, use comfortable ranges, and stop if a movement causes pain.
- Service worker cache bumped to v8. Existing SQLite data and workout history are not modified; the release ZIP excludes the `data` folder.

## v0.9.0 — Shadow Monarch artwork and multi-account login

- Replaced the geometric placeholder beside **ARISE, SHADOW HUNTER** with a cinematic Shadow Monarch portrait image bundled locally at `public/assets/shadow-monarch.webp`.
- Added a login screen with username/email + password, account registration, and first-login password setup for the existing Hunter profile.
- Added an account menu from the top-right profile circle. Create another account, log out, and log in to another account from the same installation.
- Accounts have separate profiles, theme settings, exercise libraries, programmes, XP records, backups, and workout histories. The existing database content is migrated into the original **Hunter** account automatically; the database file is not replaced by this update.
- Passwords are stored as salted scrypt hashes. Login sessions are stored server-side and expire after 30 days.
- The app remains a local Node.js + SQLite installation. Accounts are available to devices that can reach the same server, but this is not cloud hosting. Do not expose the server directly to the public internet; use HTTPS and additional deployment hardening for internet-facing use.

### Updating from v0.8
1. Close SHADOW SYSTEM and stop its server window.
2. Extract this release into the existing SHADOW SYSTEM folder and overwrite app files.
3. Keep the existing `data` folder and `shadow-system.sqlite` database.
4. Run `START-SHADOW-SYSTEM.bat`, then refresh the browser with `Ctrl+Shift+R`.
5. On first launch, log in to the existing Hunter account and set its username/password when prompted. Use **Create Account** for additional separate profiles.


## v0.10 cloud snapshot integration
- Optional Supabase email/password cloud identity, separate from the local device login.
- Manual upload and restore of a full account snapshot through Supabase REST API.
- Cloud data is protected by the `hunter_cloud_state` Row Level Security policies in `supabase/migrations/0001_cloud_sync.sql`.
- Upload replaces the cloud snapshot; restore replaces local account data after confirmation. Export a local backup before restoring.
- This is a first manual-sync implementation, not automatic bidirectional sync. Conflict resolution, background sync, and secure hosted deployment remain future work.
- The Supabase URL and publishable key are public client configuration; never add a service-role/secret key.

## v0.10 cloud snapshot integration
- Optional Supabase email/password cloud identity, separate from local device login.
- Manual upload and restore of a full account snapshot through Supabase REST API.
- Cloud data is protected by the `hunter_cloud_state` Row Level Security policies in `supabase/migrations/0001_cloud_sync.sql`.
- Upload replaces the cloud snapshot; restore replaces local account data after confirmation. Export a local backup before restoring.
- This is a first manual-sync implementation, not automatic bidirectional sync. Conflict resolution, background sync, and secure hosted deployment remain future work.
- The Supabase URL and publishable key are public client configuration; never add a service-role/secret key.
